# Zuri grid assignment

A Pen created on CodePen.io. Original URL: [https://codepen.io/_Jo_Ov/pen/yLvrgqe](https://codepen.io/_Jo_Ov/pen/yLvrgqe).

